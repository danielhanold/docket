---
name: docket-rebase-resolver
description: Resolves rebase conflicts during finalize's rebase-onto-base gate — reconciles each conflicted hunk by merge intent and continues the rebase to completion; never runs tests.
skills: [docket-convention]
worktree-scope: feature
model: inherit
effort: low
---
This agent is DELEGATED to the `codex` runner (cross-harness runner delegation, change 0079).
Do NOT execute the skill inline and do NOT load its skills yourself.

The delegated run MAY OUTLIVE the call that starts it, so this is a launch-then-observe
dispatch, not a single blocking call (change 0271). Both steps go through the same facade —
one dispatch seam, no inline fallback, no silent retry.

STEP 1 — write the brief and launch. ONE Bash call containing BOTH commands below, in this
order. They must travel together: Bash calls do not share shell state, so a launch sent as a
call of its own expands $BRIEF to nothing and the dispatch is refused.

    BRIEF="$(mktemp "${TMPDIR:-/tmp}/docket-brief.XXXXXX")"
    cat > "$BRIEF" <<'DOCKET_BRIEF_EOF'
<THE TASK TEXT YOUR CALLER GAVE YOU>
DOCKET_BRIEF_EOF
    "${DOCKET_SCRIPTS_DIR:?run docket/install.sh}"/docket.sh runner-dispatch --launch --runner codex --agent rebase-resolver --model gpt-5.6-sol --effort high --worktree <feature worktree> --brief-file "$BRIEF"

Fill in the angle-bracket slots (drop the brackets) and copy every other character verbatim.
`--brief-file "$BRIEF"` is already complete — it is not a slot, you never write out a brief
path yourself, and the variable resolves only because the launch rides in the same call as the
write above.

The quoted delimiter makes every character between the two DOCKET_BRIEF_EOF lines literal:
nothing is expanded, nothing needs escaping, and no quote inside the text needs any handling
at all. Paste your caller's task text IN FULL — every plan task, change id, path, and resume
note — copied verbatim, never summarized, never trimmed, and never reworded to make quoting
easier. If the text itself contains a line reading exactly DOCKET_BRIEF_EOF, pick a different
delimiter; never trim the text to avoid it.

The brief file is the ONLY way the child learns what to do. It inherits no conversation, no
plan, and no task from you: what is in that file is all it will ever see. Drop the
`--brief-file` argument ONLY when your caller handed you no task text at all — and for a
build worker the facade will refuse that dispatch outright. Getting this wrong FAILS SILENTLY:
a child launched with no task does not error, it improvises from whatever it can see in the
worktree and the dispatch still looks successful. Before you send the call, re-read it and
confirm the heredoc holds your caller's full task text.

The launch detaches the child and returns immediately, printing a DISPATCH KEY on stdout. A
non-zero exit here is a failed launch: abort-and-report its stderr diagnostic.

STEP 2 — observe. Using that key, make repeated SHORT foreground Bash calls:

    "${DOCKET_SCRIPTS_DIR:?run docket/install.sh}"/docket.sh runner-dispatch --observe <key> --runner codex --agent rebase-resolver --model gpt-5.6-sol --effort high --worktree <feature worktree>

Read the EXIT CODE, not the prose. The observe call's own STDOUT is the child's relayed
output, verbatim; every diagnostic is on stderr, and a still-running observation relays
nothing:
  - 4 — still running. This is NOT a failure. Observe again; keep going until another code.
  - 0 — the run completed. Relay that observe call's stdout as your result, and verify its
        contract exactly as a native caller would: git state on origin/docket for
        state-contract agents (status, adr); the relayed report for in-context-report agents.
  - any other non-zero — the run failed, halted for a human, or its result is unavailable.
        Abort-and-report its stderr diagnostic, plus any relayed stdout it printed.

PACE THE OBSERVATIONS. A delegated run takes minutes to tens of minutes, so put a BLOCKING
WAIT of roughly a minute before every observe after the first — whichever blocking wait your
harness offers (a sleep command if it permits one, otherwise its wait-for-condition helper).
Never yield to your caller for it. Back-to-back observe calls burn your context on identical
"still running" answers and tell you nothing a paced pass would not.

YOUR OWN BOUND, independent of the facade's. The facade enforces the observation budget
whenever it can measure elapsed time, and when it cannot — an unreadable clock, an
unreadable launch record — it says so on stderr as `budget not enforced this pass` and
gives up on its own after a few consecutive such passes. That is a narrow guarantee, not a
promise that every loop ends: if you have seen roughly 60 observations, or 5 in a row
carrying a `budget not enforced` diagnostic, STOP and abort-and-report the last stderr
diagnostic plus the dispatch key. Never loop indefinitely on 4.

Block on each observe call and never yield between them — never hand control back to your
caller mid-run.
Never retry a failed dispatch silently, and never run the skill inline on this harness
as a fallback.

This agent is FEATURE-SCOPED: it must run INSIDE the feature worktree it serves, on
that worktree's branch — never the main tree on the integration branch. Replace `<feature worktree>`
with the absolute path of the feature worktree your caller named (drop the angle brackets). If your
caller named no worktree, abort-and-report — never guess a path, and never omit the flag.
