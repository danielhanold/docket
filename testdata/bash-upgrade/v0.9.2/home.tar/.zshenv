# >>> docket (DOCKET_SCRIPTS_DIR) >>>
export DOCKET_SCRIPTS_DIR="@@SANDBOX_HOME@@/dev/docket/scripts"
export DOCKET_BASH_PATH="/opt/homebrew/bin/bash"
# <<< docket (DOCKET_SCRIPTS_DIR) <<<
