---
id:                       # set by docket-new-change (max existing id + 1)
slug:
title:
status: proposed
priority: medium
type:                     # chore|docs|feat|fix|refactor|perf (per change_types)
created:                  # YYYY-MM-DD (UTC)
updated:                  # YYYY-MM-DD (UTC)
depends_on: []
stacked_on:               # optional: parent change id whose branch this one is built on
related: []
discovered_from: []       # change id(s) whose work surfaced this; empty for deliberately planned work
adrs: []
spec:                     # path under docs/superpowers/specs/ once brainstormed (omit if trivial)
plan:                     # left empty; set by docket-implement-next at build time
results:                  # left empty; set by docket-implement-next at close-out if warranted
trivial: false            # true for a small mechanical change with no design questions
auto_groomable:           # tri-state: unset ⇒ inherit repo auto_groom; true/false ⇒ explicit override
branch:
pr:
blocked_by:
reconciled: false
---

## Artifacts

<!-- docket:artifacts:start (generated — do not hand-edit) -->
<!-- docket:artifacts:end -->

## Why

<!-- The motivation. Why does this work matter now? As detailed as warranted. -->

## What changes

<!-- PM-altitude scope of the work. The detailed design lives in the linked spec, not here. -->

## Out of scope

<!-- Explicit non-goals, so reconcile and review don't scope-creep. -->

## Open questions

<!-- Unknowns to resolve during reconcile/design. Delete if none. -->

## Reconcile log

<!-- Appended by docket-implement-next's reconcile pass: dated entries of what changed. -->
